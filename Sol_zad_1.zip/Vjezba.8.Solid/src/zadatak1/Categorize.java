package zadatak1;

public class Categorize {
	
	
	public Categorize() {
		
	}
	
	public void categorize(String cat) {
		
		
	}

}
