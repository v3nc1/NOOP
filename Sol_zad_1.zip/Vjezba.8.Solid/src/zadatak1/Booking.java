package zadatak1;

public class Booking {
	
	
	public Booking() {
		
		
		
	}
	
	public void makeBooking(Apartment apt) {
		
		System.out.println("Booking made");
		
	}
	
	public void cancelBooking(Apartment apt) {
		
	}
	
	
}
