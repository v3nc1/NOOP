package zadatak3;

public class ExperincedMaster extends Master {
	
	
	
	public ExperincedMaster(String name) {
		this.name=name;
		description=getClass().getSimpleName();
	}

}
