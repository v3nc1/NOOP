package zadatak3;

public class SupremeMaster extends Master {
	
	
	
	public SupremeMaster(String name) {
		this.name=name;
		description=getClass().getSimpleName();
	}

}
