package zadatak3;

public class NoviceMaster extends Master {
	
	

	public NoviceMaster(String name) {
		this.name=name;
		description=getClass().getSimpleName();
		
	}
	
	
	
	
}
