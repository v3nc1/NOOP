package zadatak5;

public interface IPilot {
	
	public void start();
	
	public void navigate();
	
	public void end();
	
	public String pilotVer();

}
