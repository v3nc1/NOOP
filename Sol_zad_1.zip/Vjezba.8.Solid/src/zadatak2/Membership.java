package zadatak2;

public interface Membership {
	
	public String memberStatus();
	
	

}
