package zadatak2;

public class BronzeMember implements Membership {

	@Override
	public String memberStatus() {
		
		return "Status Bronze member";
	}

}
