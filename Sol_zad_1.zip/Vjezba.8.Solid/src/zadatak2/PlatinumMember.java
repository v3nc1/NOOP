package zadatak2;

public class PlatinumMember implements Membership {

	@Override
	public String memberStatus() {
		
		return "Status Platinum member";
	}

}
