package zadatak2;

public class GoldMember implements Membership {

	@Override
	public String memberStatus() {
		
		return "Status Gold member";
	}

	

}
