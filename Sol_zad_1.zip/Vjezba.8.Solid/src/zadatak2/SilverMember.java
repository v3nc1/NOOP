package zadatak2;

public class SilverMember implements Membership {

	@Override
	public String memberStatus() {
		
		return "Status Silver member";
	}

}
