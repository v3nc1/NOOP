package zadatak4;

public interface ChineseRecipe {
	
	public void generateChineseRecipe();
}
