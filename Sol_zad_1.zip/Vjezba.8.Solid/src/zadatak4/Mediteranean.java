package zadatak4;

public interface Mediteranean {
	
	public void generateMeditrraneanRecipe();

}
