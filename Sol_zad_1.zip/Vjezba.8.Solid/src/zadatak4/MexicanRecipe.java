package zadatak4;

public interface MexicanRecipe {
	
	public void generateMexicanRecipe();

}
