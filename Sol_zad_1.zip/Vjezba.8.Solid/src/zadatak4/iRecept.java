package zadatak4;

public interface iRecept {
	
	public void provideAdditionalInfo();
	public void recommendWebSources();

}
