package zadatak4;

public interface IndianRecipe {
	
	public void generateIndianRecipe();

}
