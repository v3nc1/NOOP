
public class Theme3Factory implements AbsFactoryTheme {

	@Override
	public ScrollBar createScrollBar() {
		
		
		return null;
	}

	@Override
	public MenuBar createMenuBar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public StatusBar createStatusBar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ToolBar createToolBar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Window createWindow() {
		// TODO Auto-generated method stub
		return null;
	}

}
